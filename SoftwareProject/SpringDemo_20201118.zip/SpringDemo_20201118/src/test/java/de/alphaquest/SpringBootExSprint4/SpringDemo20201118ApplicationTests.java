package de.alphaquest.SpringBootExSprint4;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDemo20201118ApplicationTests {

	@Test
	void contextLoads() {
	}

}
