package de.alphaquest.SpringBootExSprint4.Data;

import java.time.Duration;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NonNull;

@Data
@AllArgsConstructor
public class ProjectTimeStamp {
    private @NonNull String UserName;
    private String timeStamp;
    private long duration;
    private @NonNull String projName;
    private String description;

    public static LocalDate stringToDate(String StringDate) {

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        LocalDate date = LocalDate.parse(StringDate, formatter);

        return date;
    }


    public static long intervalToDuration(String sStart, String sEnd) {

        LocalDate ltstartdate = LocalDate.parse(sStart, DateTimeFormatter.ofPattern("yyyyMMdd"));
        LocalDate ltenddate = LocalDate.parse(sEnd, DateTimeFormatter.ofPattern("yyyyMMdd"));
        return ChronoUnit.DAYS.between(ltstartdate,ltenddate);
    }




}
