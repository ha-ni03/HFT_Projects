package de.alphaquest.SpringBootExSprint4.Controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

// An attempt to use thymeleaf
@Controller
public class MyWebController {

    @GetMapping("/handshake")
    public String AgreesPage(@RequestParam(name="hellotext", required=false, defaultValue="HI Swagger Succeeded")String OurText, Model model)
    {
        OurText = "Finally Swagger agrees with AlphaQuest";
        model.addAttribute("hellotext",OurText);
        return "handshake";
    }
}
