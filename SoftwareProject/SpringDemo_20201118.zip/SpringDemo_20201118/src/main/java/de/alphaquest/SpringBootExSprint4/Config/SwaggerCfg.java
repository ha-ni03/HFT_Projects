package de.alphaquest.SpringBootExSprint4.Config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

@Configuration
@EnableSwagger2
public class SwaggerCfg {

    @Bean
    public Docket api() {
        return new Docket(DocumentationType.SWAGGER_2).select().apis(RequestHandlerSelectors.basePackage("de.alphaquest"))
                .paths(PathSelectors.any()).build().apiInfo(metadata());
    }

    private ApiInfo metadata() {
        return new ApiInfoBuilder()
                .title("SringBoot-Swagger-Lombok-Demo")
                .description("Demo exploring the features of Spring boot framework swagger and lombok components, from Harini, Blue team")
                .version("1.0.0")
                .contact(new Contact("AlphaQuest GmbH","https://www.alphaquest.de/","info@Alphaquest.de"))
                .build();
    }

}
