package de.alphaquest.SpringBootExSprint4.Controllers;

import de.alphaquest.SpringBootExSprint4.Data.ProjectTimeStamp;
import io.swagger.annotations.ApiOperation;
import lombok.extern.apachecommons.CommonsLog;
import lombok.extern.flogger.Flogger;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import lombok.extern.java.Log;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Slf4j
@RestController
@RequestMapping("/project")
public class ProjectLoginController {
    ArrayList<ProjectTimeStamp> entries = new ArrayList<ProjectTimeStamp>();
    String StringTimeStamp ;
    private Logger log = LoggerFactory.getLogger(ProjectLoginController.class);


    // AddEntry Method
    @ApiOperation(value = "Add a new time entry", notes = "Remember: username = String, date = String (YYYYMMDD), start = String (YYYYMMDD),end = String (YYYYMMDD)project_name = String, task_description = String")
    @GetMapping("/addEntry/{username}/{start}/{end}/{projname}/{description}")
    public ProjectTimeStamp addEntry(@PathVariable String username, @PathVariable String start, @PathVariable String end,@PathVariable String projname,
                              @PathVariable String description) {

        long duration = ProjectTimeStamp.intervalToDuration(start,end);
        StringTimeStamp = Instant.now().toString();

        log.info("addEntry method invoked with parameters user_name = {}, date= {}, duration= {}, project_name= {}, project_description= {}",
                username,StringTimeStamp, duration, projname, description);
        ProjectTimeStamp entry = new ProjectTimeStamp(username,StringTimeStamp, duration, projname, description);
        entries.add(entry);
        return entry;

    }

    // ListAll Methods
    @ApiOperation(value = "Lists all time entries")
    @GetMapping("/listAll")
    public ArrayList<ProjectTimeStamp> listAll() {
        return entries;
    }

    // Listall Users
    @ApiOperation(value = "Lists all users")
    @GetMapping("/listUsers")
    public List<String> listUsers() {

        List<String> users = entries.stream().map(u -> u.getUserName()).collect(Collectors.toList());
        return users;
    }

    @ApiOperation(value = "Delete an entry based on the Project Name", notes = "Remember: Use a project name to delete a time entry")
    @GetMapping("/deleteEntry/{projectToDelete}")
    public ArrayList<ProjectTimeStamp> deleteEntry(@PathVariable String projectToDelete) {

        log.debug("trying to delete Project {}", projectToDelete);
        log.info("list prior to deletion: {}", listAll());
        entries.removeIf(e -> e.getProjName().equals(projectToDelete));
        log.debug("list after deletion: {}", listAll());
        return entries;

    }

}
