package de.alphaquest.SpringBootExSprint4;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.eclipse.jetty.server.Server;

@SpringBootApplication
public class SpringBootExSprint4 {

	public static void main(String[] args) {

		// Init server
		Server server = new Server(9010);

		SpringApplication.run(SpringBootExSprint4.class, args);
	}

}
