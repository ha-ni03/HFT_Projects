package de.alphaquest.SpringBootExSprint4.Controllers;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// First step to check if Hello world works
@Api(value = "Hello World Controller")
@RestController
public class MyHelloWorldController
{
    @RequestMapping("/")
    @ApiOperation(value ="Testing Hello World with Swagger")
    public String hello()
    {
        return "Hello World from AlphaQuest Team Blue";
    }

}
